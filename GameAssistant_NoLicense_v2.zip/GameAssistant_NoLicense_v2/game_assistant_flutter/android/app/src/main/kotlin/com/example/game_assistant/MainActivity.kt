package com.example.game_assistant

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "game_assistant/native"
        private const val REQUEST_OVERLAY = 701
        private const val REQUEST_CAPTURE = 702
    }

    private var projectionResultCode: Int = 0
    private var projectionData: Intent? = null
    private var tts: TextToSpeech? = null

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "hasOverlayPermission" -> result.success(Settings.canDrawOverlays(this))
                "requestOverlayPermission" -> {
                    if (!Settings.canDrawOverlays(this)) {
                        startActivityForResult(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                            REQUEST_OVERLAY
                        )
                    }
                    result.success(Settings.canDrawOverlays(this))
                }
                "startAssistant" -> {
                    if (!Settings.canDrawOverlays(this)) {
                        result.success(false)
                    } else {
                        val intent = Intent(this, AssistantForegroundService::class.java)
                        intent.action = AssistantForegroundService.ACTION_START
                        startForegroundService(intent)
                        result.success(true)
                    }
                }
                "stopAssistant" -> {
                    stopService(Intent(this, AssistantForegroundService::class.java))
                    result.success(true)
                }
                "requestRecorderPermission" -> {
                    val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
                    result.success(true)
                }
                "startRecorder" -> {
                    val data = projectionData
                    if (data == null) {
                        result.success(false)
                    } else {
                        val i = Intent(this, AssistantForegroundService::class.java)
                        i.action = AssistantForegroundService.ACTION_START_RECORDER
                        i.putExtra("resultCode", projectionResultCode)
                        i.putExtra("data", data)
                        startForegroundService(i)
                        result.success(true)
                    }
                }
                "stopRecorder" -> {
                    val i = Intent(this, AssistantForegroundService::class.java)
                    i.action = AssistantForegroundService.ACTION_STOP_RECORDER
                    startService(i)
                    result.success(true)
                }
                "setHudFeature" -> {
                    val feature = call.argument<String>("feature") ?: ""
                    val enabled = call.argument<Boolean>("enabled") ?: false
                    val i = Intent(this, OverlayService::class.java)
                    i.action = OverlayService.ACTION_FEATURE
                    i.putExtra("feature", feature)
                    i.putExtra("enabled", enabled)
                    startService(i)
                    result.success(true)
                }
                "speak" -> {
                    val text = call.argument<String>("text").orEmpty()
                    if (text.isNotBlank()) {
                        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "game_assistant_reply")
                    }
                    result.success(true)
                }
                "startVoice", "stopVoice" -> result.success(true)
                "getLastRecordingPath" -> result.success(AssistantForegroundService.lastRecordingPath)
                else -> result.notImplemented()
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == Activity.RESULT_OK && data != null) {
            projectionResultCode = resultCode
            projectionData = data
        }
    }
}
