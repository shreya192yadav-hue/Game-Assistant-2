package com.example.game_assistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Environment
import androidx.core.app.NotificationCompat
import java.io.File

class AssistantForegroundService : Service() {
    companion object {
        const val ACTION_START = "START_ASSISTANT"
        const val ACTION_START_RECORDER = "START_RECORDER"
        const val ACTION_STOP_RECORDER = "STOP_RECORDER"
        var lastRecordingPath: String? = null
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForegroundCompat()
        OverlayService.start(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                OverlayService.start(this)
            }
            ACTION_START_RECORDER -> {
                val resultCode = intent.getIntExtra("resultCode", 0)
                val data = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra("data", Intent::class.java)
                else
                    @Suppress("DEPRECATION") intent.getParcelableExtra("data")
                if (data != null) {
                    if (Build.VERSION.SDK_INT >= 29) {
                        val notification = NotificationCompat.Builder(this, "assistant")
                            .setContentTitle("Game Assistant")
                            .setContentText("Screen recorder is running")
                            .setSmallIcon(android.R.drawable.ic_media_play)
                            .setOngoing(true)
                            .build()
                        startForeground(
                            42,
                            notification,
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC or
                                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                        )
                    }
                    startRecording(resultCode, data)
                }
            }
            ACTION_STOP_RECORDER -> stopRecording()
        }
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val notification = NotificationCompat.Builder(this, "assistant")
            .setContentTitle("Game Assistant")
            .setContentText("Assistant is running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                42,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(42, notification)
        }
    }

    private fun startRecording(resultCode: Int, data: Intent) {
        if (projection != null) return

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        val file = File(dir, "game_${System.currentTimeMillis()}.mp4")
        lastRecordingPath = file.absolutePath

        recorder = MediaRecorder(this).apply {
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setVideoEncodingBitRate(12_000_000)
            setVideoFrameRate(60)
            setVideoSize(width, height)
            setOutputFile(file.absolutePath)
            prepare()
        }

        virtualDisplay = projection!!.createVirtualDisplay(
            "GameAssistantRecorder",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            recorder!!.surface,
            null,
            null
        )
        recorder!!.start()
        OverlayService.setStatus(this, "REC ●")
    }

    private fun stopRecording() {
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset() } catch (_: Exception) {}
        recorder?.release()
        recorder = null
        virtualDisplay?.release()
        virtualDisplay = null
        projection?.stop()
        projection = null
        OverlayService.setStatus(this, "REC OFF")
    }

    override fun onDestroy() {
        stopRecording()
        OverlayService.stop(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "assistant",
                "Game Assistant",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
