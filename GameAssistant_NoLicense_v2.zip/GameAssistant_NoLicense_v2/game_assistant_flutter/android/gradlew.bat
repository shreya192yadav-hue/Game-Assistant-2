@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle wrapper JAR is not bundled. Run "flutter create ." once in the project root or install Gradle.
exit /b 1
