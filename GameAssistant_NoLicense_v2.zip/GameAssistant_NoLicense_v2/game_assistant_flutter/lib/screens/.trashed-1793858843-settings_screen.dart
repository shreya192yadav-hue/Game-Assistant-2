import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/assistant_controller.dart';
import '../core/theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final AssistantController controller;
  late final TextEditingController geminiController;

  @override
  void initState() {
    super.initState();
    controller = Get.find<AssistantController>();
    geminiController = TextEditingController(text: controller.geminiKey.value);
  }

  @override
  void dispose() {
    geminiController.dispose();
    super.dispose();
  }

  void _showMessage(String title, String message) {
    Get.snackbar(
      title,
      message,
      snackPosition: SnackPosition.BOTTOM,
      margin: const EdgeInsets.all(12),
      backgroundColor: card,
      colorText: Colors.white,
      duration: const Duration(seconds: 3),
    );
  }

  @override
  Widget build(BuildContext context) {
    final features = <String>[
      'Gemini AI brain',
      'Floating game HUD',
      'Voice-ready controls',
      '360° direction / compass',
      'High-FPS screen recording',
      'English → Nepali OCR pipeline',
      'Flutter ↔ Kotlin native bridge',
      'Foreground service',
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('SETTINGS'),
      ),
      body: Obx(
        () => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'GEMINI API KEY',
              style: TextStyle(
                color: neonGreen,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.1,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: geminiController,
              obscureText: true,
              autocorrect: false,
              enableSuggestions: false,
              decoration: const InputDecoration(
                hintText: 'Paste Gemini API key',
                prefixIcon: Icon(Icons.key),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: controller.busy.value
                    ? null
                    : () async {
                        final value = geminiController.text.trim();
                        if (value.isEmpty) {
                          _showMessage('Gemini', 'Please enter your API key.');
                          return;
                        }

                        final ok = await controller.saveAndValidateGemini(value);

                        if (!mounted) return;

                        _showMessage(
                          'Gemini',
                          ok
                              ? 'API key validated and securely stored.'
                              : 'API key validation failed.',
                        );
                      },
                icon: controller.busy.value
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.verified),
                label: Text(
                  controller.busy.value ? 'VALIDATING...' : 'VALIDATE & SAVE',
                ),
              ),
            ),
            const SizedBox(height: 28),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'APP FEATURES',
                      style: TextStyle(
                        color: neonGreen,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    ...features.map(
                      (feature) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(top: 2),
                              child: Icon(
                                Icons.check_circle_outline,
                                size: 18,
                                color: neonGreen,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(child: Text(feature)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            Card(
              child: Column(
                children: [
                  SwitchListTile.adaptive(
                    title: const Text('Voice controls'),
                    subtitle: const Text('Enable voice-ready HUD controls'),
                    value: controller.voiceEnabled.value,
                    onChanged: (value) => controller.setFeature('voice', value),
                    secondary: const Icon(Icons.mic),
                  ),
                  SwitchListTile.adaptive(
                    title: const Text('360° Compass'),
                    subtitle: const Text('Show direction information'),
                    value: controller.compassEnabled.value,
                    onChanged: (value) =>
                        controller.setFeature('compass', value),
                    secondary: const Icon(Icons.explore),
                  ),
                  SwitchListTile.adaptive(
                    title: const Text('Screen Translator'),
                    subtitle: const Text('English → Nepali OCR pipeline'),
                    value: controller.translatorEnabled.value,
                    onChanged: (value) =>
                        controller.setFeature('translator', value),
                    secondary: const Icon(Icons.translate),
                  ),
                  SwitchListTile.adaptive(
                    title: const Text('High-FPS Recorder'),
                    subtitle: const Text('Use Android screen recording service'),
                    value: controller.recorderEnabled.value,
                    onChanged: controller.toggleRecorder,
                    secondary: const Icon(Icons.videocam),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Card(
              child: SwitchListTile.adaptive(
                title: const Text('Game Assistant HUD'),
                subtitle: Text(
                  controller.overlayAllowed.value
                      ? 'Floating overlay permission available'
                      : 'Android overlay permission required',
                ),
                value: controller.assistantRunning.value,
                onChanged: controller.toggleAssistant,
                secondary: Icon(
                  controller.assistantRunning.value
                      ? Icons.stop_circle
                      : Icons.play_circle,
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'No license system is included. The app can start directly after the required Android permissions are granted.',
              style: TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}
